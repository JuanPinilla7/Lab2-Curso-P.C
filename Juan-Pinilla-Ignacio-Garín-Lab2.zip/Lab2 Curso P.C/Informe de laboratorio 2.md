![Logo UCN](60x60-ucn-negro.png)
# Laboratorio 02: Visualización de mapas de calor

**Alumnos:** Juan Pinilla, Ignacio Garín

**Docentes:** Juan Bekios, Diego Valdivia

**Ayudante:** Cristian Galleguillos 

## 1. Introducción 

**Definición del problema** (600 caracteres máximo)

Dado un conjunto de archivos de texto que contienen coordenadas representando la dirección y sentido en que los peatones transitan con respecto al ancho de las paredes, se requiere la creación de un gráfico que posibilite la visualización del movimiento peatonal. Este gráfico deberá resaltar la frecuencia de cada par de coordenadas, permitiendo una comprensión más profunda de los datos.

Adicionalmente, se solicita llevar a cabo una comparativa del rendimiento computacional al realizar este análisis con y sin la librería Pandas.

### 1.1 Justificación (500 caracteres máximo)

La eficiencia de un código de programación influye en la velocidad de ejecución y el uso de memoria RAM y CPU. Sin embargo, en ocasiones, abordar estos problemas resulta difícil debido a limitaciones de recursos. En un laboratorio previo, se procesaron datos de forma manual, lo que afectó la eficiencia. Por ello, en este nuevo laboratorio, se empleará una biblioteca especializada para demostrar su utilidad y ventajas en términos de rendimiento y recursos.

### 1.2 Objetivos 

**Objetivo General**

Realizar un análisis de frecuencia de peatones mediante la creación de un histograma en 2D con el lenguaje de programación Python.

**Objetivos específicos**

1. Generar DataFrame a partir del archivo del conjunto de texto.

2. Generar gráfico de histograma 2D.

3. Comparar el desempeño computacional de los algoritmos con y sin librerías.

## 2. Marco teórico (800 caracteres)

**Python**: Lenguaje de programación de alto nivel, ampliamente uilizado.

**Visual Studio**: Editor de código fuente altamente popular, desarrollado por Microsoft. Es una herramienta de programación de código abierto que admite múltiples lenguajes de programación y proporciona una amplia gama de características útiles.

**Librerías utilizadas**:
- Pandas: Librería de Python especializada en el manejo y análisis de estructuras de datos.
- NumPy: Biblioteca para cálculos numéricos y manipulación de arreglos multidimensionales.
- Matplotlib: Biblioteca para crear gráficos y visualizaciones de datos en diversas dimensiones.
- Time: Módulo para trabajar con el tiempo y medir el rendimiento en Python.
- Psutil: Biblioteca para obtener información y controlar procesos y recursos del sistema operativo en Python.

## 3. Materiales y métodos

Se usaron dos datasets de nombres "UNI_CORR_500_01" y "UNI_CORR_500_06". Los archivos de texto tienen 5 columnas y más de 25.000 filas. Describen la ubicación de las personas usando sus coordenadas x,y,z en diferentes frames. Las posiciones se expresan en metros. La diferencia entre ambos es la longitud de las puertas, teniendo el primero entradas de 1 y 5 metros, y el segundo de 5 y 4 metros. 

El experimento busca analizar la densidad de las personas en un pasillo mediante mapas de calor. Se deben crear dos algoritmos diferentes, uno de forma tradicional y otro usando librerías.

Primero el algoritmo sin librerías. Ya que se trabajó con la misma estructura de datos del laboratorio pasado el proceso de visualización y filtrado es el mismo. Las primeras 4 filas del archivo son encabezados así que se omiten, luego se usa la función "split" para separar la línea completa cada vez que se encuentre un vacío. La única información necesaria son las coordenadas X e Y del peatón, por lo que se guardan en listas y se aplica inmediatamente la transformación de metro a pixel.

El mapa de calor generado con Matplotlib recibe estas listas de coordenadas como parámetros, adicional a otras características como título del gráfico, etiquetas de eje o barra de intensidad.

Por último, se tiene una función capaz de medir el desempeño computacional. Esta recibe un parámetro, por lo que todo el programa principal se encapsula en una función y se entrega. Ya que se deben analizar dos archivos de texto pero no se quiere calcular métricas dos veces, se crea otra función dentro de la principal y esta sí recibe el nombre y el número del archivo pero la ejecución es idéntica. El tiempo es simplemente la resta entre el fin del programa y el inicio, medido en milisegundos.

Sobre el algoritmo desarrollado con la librería Pandas, se mantiene la misma lógica pero el código es un poco más acotado. No se debe recorrer línea por línea, separando por vacíos y filtrando por columna, aquí en una sola instrucción genera un dataframe, saltándose las primeras tres líneas y usando la cuarta como cabecera, separando la información por cada tabulador que encuentre. Para generar el mapa de calor se referencian solo a las columnas de nombre "X" e "Y". El resto del algoritmo es idéntico.

## 4. Resultados obtenidos

Ambos algoritmos se ejecutaron satisfactoriamente, mostrando por pantalla los mapas de calor del movimiento peatonal.

![Muestra 1](muestra1.png)

![Muestra 6](muestra6.png)

En el primer caso, al tener una puerta más pequeña, la densidad de personas es mucho menor (se puede observar en la barra de color) y tienden a salir en direcciones opuestas, despejando algunos sectores como la franja central y los extremos. Por otro lado, cuando las puertas son más grandes el flujo de personas es mucho mayor en cantidad y espacio, ocupando más superficie del corredor, aunque esto ralentice la velocidad del paso.

A continuación se muestra el desempeño computacional del algoritmo tradicional.

![Desempeño sin panda](desempe%C3%B1oSinPanda.png)

Y ahora el algoritmo implementando Pandas.

![Desempeño con panda](desempe%C3%B1oConPanda.png)

Se observa una clara disminución en los tiempos de ejecución y un menor uso de CPU. La librería Pandas agiliza bastante la creación de los arreglos con la información, ya que con el método tradicional se deben crear ciclos y listas y con Pandas en una sola instrucción se almacena todo. El aumento en el uso de la memoria puede deberse a la importación de la librería y sus funcionalidades.

## 5. Conclusiones

Luego de realizar el laboratorio se pudieron visualizar mapas de calor para dos muestreos diferentes del movimiento de peatones, dependiendo de las medidas del pasillo.

Se puede concluir que el tener accesos más amplios aumenta en gran medida el uso del espacio y la densidad de personas por metro. Esto maximiza el uso de recursos, sin embargo, puede hacer que el tránsito sea más lento.

Sobre los algoritmos desarrollados, el uso de la librería Pandas agilizó el desempeño del programa, tanto computacionalmente como en la extensión del código. Aprender más sobre las bondades de Pandas será muy importante en el futuro profesional, para trabajar problemas grandes de datos de forma más rápida y eficiente, y aún más allá, el adoptar buenas prácticas sobre el uso de librerías, que eviten realizar trabajos que ya se han hecho anteriormente.





